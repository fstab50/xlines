
**libtools** | Tools & Utilities Library
-----------------------------------------------------------

PACKAGE: libtools

``libtools``: reusable library of utility functions for use in cli programs

* User input processing
* Output processing
* Color Formatting


